param(
    [string] $SourcePath,
    [string] $TargetPath
)

$ErrorActionPreference = 'Stop'
$bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifestPath = Join-Path $bundleRoot 'patch-manifest.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json

function Get-Sha256([byte[]] $Data) {
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($Data))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose() }
}

function Test-MayuraSource([string] $Candidate) {
    if (-not (Test-Path -LiteralPath $Candidate -PathType Container)) { return $false }
    foreach ($file in $manifest.files) {
        $path = Join-Path $Candidate ([string] $file.path)
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $false }
        if ((Get-Sha256 ([IO.File]::ReadAllBytes($path))) -ne [string] $file.sourceSha256) { return $false }
    }
    return $true
}

if (-not $SourcePath) {
    $ghostRoot = Join-Path $env:LOCALAPPDATA 'Programs\SSP\ghost'
    if (Test-Path -LiteralPath $ghostRoot) {
        $SourcePath = Get-ChildItem -LiteralPath $ghostRoot -Directory |
            Where-Object { Test-MayuraSource $_.FullName } |
            Select-Object -First 1 -ExpandProperty FullName
    }
}
if (-not $SourcePath) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Select the original Mayura ghost folder (the folder containing install.txt).'
    if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw 'Installation cancelled.' }
    $SourcePath = $dialog.SelectedPath
}
$SourcePath = [IO.Path]::GetFullPath($SourcePath)
if (-not (Test-MayuraSource $SourcePath)) {
    throw 'This is not the supported original Mayura version. No files were changed.'
}
if (-not $TargetPath) {
    $TargetPath = Join-Path (Split-Path -Parent $SourcePath) ([string] $manifest.targetDirectory)
}
$TargetPath = [IO.Path]::GetFullPath($TargetPath)
if ($TargetPath -eq $SourcePath) { throw 'The English copy cannot overwrite the original Mayura folder.' }

$targetParent = Split-Path -Parent $TargetPath
[IO.Directory]::CreateDirectory($targetParent) | Out-Null
$temporary = Join-Path $targetParent ('.mayura-en-install-' + [guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($temporary) | Out-Null
try {
    Get-ChildItem -LiteralPath $SourcePath -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $temporary -Recurse -Force
    }
    foreach ($file in $manifest.files) {
        $path = Join-Path $temporary ([string] $file.path)
        [byte[]] $sourceData = [IO.File]::ReadAllBytes($path)
        $stream = New-Object IO.MemoryStream
        try {
            foreach ($chunk in $file.chunks) {
                if ($null -ne $chunk.dataBase64) {
                    [byte[]] $data = [Convert]::FromBase64String([string] $chunk.dataBase64)
                    if ($data.Length) { $stream.Write($data, 0, $data.Length) }
                } else {
                    $start = [int] $chunk.sourceOffset
                    $length = [int] $chunk.length
                    if ($start -lt 0 -or $length -lt 0 -or $start + $length -gt $sourceData.Length) {
                        throw "Invalid source range in $($file.path)."
                    }
                    if ($length) { $stream.Write($sourceData, $start, $length) }
                }
            }
            [byte[]] $data = $stream.ToArray()
        } finally { $stream.Dispose() }
        if ((Get-Sha256 $data) -ne [string] $file.outputSha256) {
            throw "Output verification failed for $($file.path)."
        }
        [IO.File]::WriteAllBytes($path, $data)
    }
    foreach ($addition in $manifest.additions) {
        $source = Join-Path $bundleRoot ('payload\' + [string] $addition.path)
        $destination = Join-Path $temporary ([string] $addition.path)
        [IO.Directory]::CreateDirectory((Split-Path -Parent $destination)) | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Force
        if ((Get-Sha256 ([IO.File]::ReadAllBytes($destination))) -ne [string] $addition.sha256) {
            throw "Payload verification failed for $($addition.path)."
        }
    }

    if (Test-Path -LiteralPath $TargetPath) {
        foreach ($relative in @('ghost\master\mayura.ini', 'ghost\master\mayura.bak', 'ghost\master\news.dat', 'ghost\master\kawari.log')) {
            $existing = Join-Path $TargetPath $relative
            if (Test-Path -LiteralPath $existing -PathType Leaf) {
                $destination = Join-Path $temporary $relative
                [IO.Directory]::CreateDirectory((Split-Path -Parent $destination)) | Out-Null
                Copy-Item -LiteralPath $existing -Destination $destination -Force
            }
        }
        foreach ($relative in @('ghost\master\profile', 'shell\master\profile')) {
            $existing = Join-Path $TargetPath $relative
            if (Test-Path -LiteralPath $existing -PathType Container) {
                Copy-Item -LiteralPath $existing -Destination (Split-Path -Parent (Join-Path $temporary $relative)) -Recurse -Force
            }
        }
        $backup = $TargetPath + '.backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
        Move-Item -LiteralPath $TargetPath -Destination $backup
        Write-Output "Previous English copy backed up to $backup"
    }
    Move-Item -LiteralPath $temporary -Destination $TargetPath
} catch {
    if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Recurse -Force }
    throw
}

Write-Output "Mayura English installed at $TargetPath"
Write-Output 'The original Mayura installation was not modified.'
