Mayura English Patch
====================

Requirements:
- The supported original Mayura must already be installed.
- SSP should be closed while installing or updating the patch.

Double-click Install-Mayura-English.cmd. The installer normally finds Mayura
automatically. If it cannot, select the original Mayura folder when prompted.

The installer verifies the original files, creates a separate mayura_en ghost,
and applies the English localization there. It never overwrites original Mayura.
When updating an existing English copy, save data is retained and the previous
copy is moved to a timestamped backup folder.

Permission and responsibility
-----------------------------

This unofficial English localization is distributed with the original author's
permission as a patch for users who already possess Mayura. It does not include
or redistribute Mayura herself.

The English localization team takes full responsibility for the translated
content. The original author did not produce or verify the English translation
and must not be held responsible or criticized for its wording or accuracy.

Mayura was created for a Japanese audience. Cultural differences may make some
original material controversial or taboo outside Japan; the original author had
no intention of disrespecting people overseas.

©2001 Little Witch Order 夢蛍
https://www.youtube.com/@JunkersHigh
